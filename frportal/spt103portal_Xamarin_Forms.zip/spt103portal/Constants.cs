﻿using System;

namespace spt103portal
{
	public static class Constants
	{
		// Replace strings with your mobile services and gateway URLs.
		public static string ApplicationURL = @"https://spt103portal.azurewebsites.net";
	}
}

